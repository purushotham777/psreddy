#!/bin/sh
set -x
curl -i http://localhost:8888/products; echo
